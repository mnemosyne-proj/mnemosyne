version = "2.3.4"

if __name__ == "__main__":
    print version
