version = "2.3.6-pre"

if __name__ == "__main__":
    print version
