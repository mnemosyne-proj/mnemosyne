version = "2.4 beta1"

if __name__ == "__main__":
    print(version)
