version = "2.3.5"

if __name__ == "__main__":
    print version
