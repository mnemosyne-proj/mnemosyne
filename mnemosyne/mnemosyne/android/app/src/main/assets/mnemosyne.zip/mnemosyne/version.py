version = "2.4"

if __name__ == "__main__":
    print(version)
