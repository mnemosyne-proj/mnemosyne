version = "2.3.5-RC3"

if __name__ == "__main__":
    print version
