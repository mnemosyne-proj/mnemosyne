version = "2.3.1-RC2"

if __name__ == "__main__":
    print version
